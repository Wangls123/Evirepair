# OpenHAB data

These files are the OpenHAB benchmark. They are not the Home Assistant single-scene or multi-action instances.

`benchmarks/public` holds 1,600 scenarios. Each scenario has items, rules, an event sequence, and an initial state.

`benchmarks/manifests/dataset_manifest.json` records the generator seed `20260909` and the scenario list. `benchmarks/splits` records the live split.

`references/openhab_semantic_reference.jsonl` is the evaluation reference: 1,600 lines, one per scenario. It is not an input to EviRepair.

`references/hidden_eval` stores the generator-side obligations, conflict relations, acceptable behaviors, and scenario intent for the same 1,600 scenarios.

The reported OpenHAB tables use this corpus as 650 single-rule scenarios and 950 multi-rule scenarios.
